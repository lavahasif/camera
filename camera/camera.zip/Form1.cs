﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenCvSharp.CPlusPlus;
using OpenCvSharp.Extensions;

namespace camera
{
    public partial class Form1 : Form
    {
        // Create class-level accesible variables
        VideoCapture capture;
        Mat frame;
        Bitmap image;
        private Thread camera;
        bool isCameraRunning = false;

        // Declare required methods
        private void CaptureCamera()
        {
            camera = new Thread(new ThreadStart(CaptureCameraCallback));
            camera.Start();
        }

        private void CaptureCameraCallback()
        {
            frame = new Mat();
            capture = new VideoCapture(0);
            capture.Open(0);

            if (capture.IsOpened())
            {
                while (isCameraRunning)
                {
                    capture.Read(frame);
                    image = BitmapConverter.ToBitmap(frame);
                    if (pictureBox1.Image != null)
                    {
                        pictureBox1.Image.Dispose();
                    }

                    pictureBox1.Image = image;
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // When the user clicks on the start/stop button, start or release the camera and setup flags
        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text.Equals("Start"))
            {
                CaptureCamera();
                button1.Text = "Stop";
                isCameraRunning = true;
            }
            else
            {
                capture.Release();
                button1.Text = "Start";
                isCameraRunning = false;
            }
        }

        // When the user clicks on take snapshot, the image that is displayed in the pictureBox will be saved in your computer
        private void button2_Click(object sender, EventArgs e)
        {
            if (isCameraRunning)
            {
                // Take snapshot of the current image generate by OpenCV in the Picture Box
                Bitmap snapshot = new Bitmap(pictureBox1.Image);

                // Save in some directory
                // in this example, we'll generate a random filename e.g 47059681-95ed-4e95-9b50-320092a3d652.png
                // snapshot.Save(@"C:\Users\sdkca\Desktop\mysnapshot.png", ImageFormat.Png);
                snapshot.Save(string.Format(@"D:\{0}.png", Guid.NewGuid()), ImageFormat.Png);
            }
            else
            {
                Console.WriteLine("Cannot take picture if the camera isn't capturing image!");
            }
        }
    }
}

// public partial class Form1 : Form
// {
//     public Form1()
//     {
//         InitializeComponent();
//         //capture = new VideoCapture(0);
//     }
//
//     VideoCapture capture;
//     Mat frame;
//     Bitmap image;
//     private Thread camera;
//     bool isCameraRunning = false;
//
//     private void CaptureCamera()
//     {
//         camera = new Thread(new ThreadStart(CaptureCameraCallback));
//         camera.Start();
//     }
//
//     private void CaptureCameraCallback()
//     {
//         frame = new Mat(600, 600,);
//         capture = new VideoCapture(0);
//         capture.Open(0);
//
//         if (capture.IsOpened())
//         {
//             while (isCameraRunning)
//             {
//                 capture.Read(frame);
//                 image = MatToBitmap(frame);
//                 // image = BitmapConverter.ToBitmap(frame);
//                 image.Save("E:\\image.jpg");
//                 if (pictureBox1.Image != null)
//                 {
//                     pictureBox1.Image.Dispose();
//                 }
//
//                 pictureBox1.Image = image;
//             }
//         }
//     }
//
//     private static Bitmap MatToBitmap(Mat mat)
//     {
//         using (var ms = mat.ToMemoryStream())
//         {
//             return (Bitmap)Image.FromStream(ms);
//         }
//     }
//
//     private void button1_Click(object sender, EventArgs e)
//     {
//         if (button1.Text.Equals("Start"))
//         {
//             CaptureCamera();
//             button1.Text = "Stop";
//             isCameraRunning = true;
//         }
//         else
//         {
//             capture.Release();
//             button1.Text = "Start";
//             isCameraRunning = false;
//         }
//     }
// }